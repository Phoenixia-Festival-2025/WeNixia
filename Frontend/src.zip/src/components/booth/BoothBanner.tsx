export default function BoothBanner() {
  return (
    <div className="w-full h-40 bg-orange-300 rounded-md flex items-center justify-center text-white text-lg font-bold">
      부스 안내 배너
    </div>
  );
}