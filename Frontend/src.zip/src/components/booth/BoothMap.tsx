export default function BoothMap() {
  return (
    <div className="w-full h-48 bg-gray-200 rounded-md flex items-center justify-center text-gray-500 text-sm">
      축제장 지도 (이미지로 교체 예정)
    </div>
  );
}