export default function Banner() {
  return (
    <div className="w-full h-40 bg-gray-300 rounded-md flex items-center justify-center">
      <span className="text-white text-lg">피닉시아 2025 배너</span>
    </div>
  );
}