export default function NoticeBanner() {
  return (
    <div className="w-full h-40 bg-yellow-300 rounded-md flex items-center justify-center text-white text-lg font-bold">
      📢 공지사항
    </div>
  );
}